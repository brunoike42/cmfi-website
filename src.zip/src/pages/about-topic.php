<?php
require_once __DIR__ . '/../about_topics.php';
$topics = about_topics();
if (!isset($topics[$topic])) {
    http_response_code(404); head('Not found', '/about');
    echo '<div class="wrap"><h1>Page not found</h1><p><a href="/about">Back to About us</a></p></div>'; foot(); return;
}
$t = $topics[$topic]; $a = single('about');
head($t['title'], '/about');
$blocks = q('SELECT * FROM about_blocks WHERE topic = ? AND COALESCE(hidden,0) = 0 ORDER BY COALESCE(sort_order,0), id', [$topic]);
$bg = $t['banner'] ? ' style="background-image:linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)),url(\'' . e($t['banner']) . '\')"' : '';
?>
<section class="abn"<?= $bg ?>><div class="wrap">
  <p class="abback"><a href="/about">&larr; About us</a></p>
  <h1><?= e($t['title']) ?></h1>
  <?php if ($t['tagline'] !== ''): ?><p class="abtag"><?= e($t['tagline']) ?></p><?php endif; ?>
  <span class="abline" aria-hidden="true"></span>
</div></section>
<div class="wrap">
<?php if (lines($t['numbers'])): ?>
  <div class="kn"><?php foreach (lines($t['numbers']) as $l): [$n, $lab] = parts($l, 2); ?><div><b><?= e($n) ?></b><span><?= e($lab) ?></span></div><?php endforeach; ?></div>
<?php endif;

$i = 0;
if (in_array($topic, ['vision', 'mission', 'goals'], true)) {
    $text = $topic === 'goals'
        ? (lines($a['goals'] ?? '') ? '<ul>' . implode('', array_map(fn($g) => '<li>' . e($g) . '</li>', lines($a['goals']))) . '</ul>' : '')
        : about_paragraphs($a[$topic] ?? '');
    [$kind, $up] = about_upload($a[$topic . '_file'] ?? '', $t['title']);
    if ($kind === 'pdf') { $text .= $up; $up = ''; }
    if ($text === '' && $up === '') $text = '<p class="muted">Not added yet. Add it in the admin under About page.</p>';
    echo about_block($text, $up, $i++);
} elseif ($topic === 'story') {
    $text = about_paragraphs($a['story'] ?? '') ?: '<p class="muted">Add the church story in the admin under About page.</p>';
    echo about_block($text, '', $i++);
    if (lines($a['timeline'] ?? '')) {
        echo '<h2>Along the way</h2><ol class="timeline">';
        foreach (lines($a['timeline']) as $l) { [$y, $ev] = parts($l, 2); echo '<li><b>' . e($y) . '</b> ' . e($ev) . '</li>'; }
        echo '</ol>';
    }
} elseif ($topic === 'beliefs') {
    if (lines($a['beliefs'] ?? '')) {
        echo '<div class="grid">';
        foreach (lines($a['beliefs']) as $l) { [$bt, $bs] = parts($l, 2); echo '<div class="card"><h3>' . e($bt) . '</h3><p class="muted">' . e($bs) . '</p></div>'; }
        echo '</div>';
    } else echo '<p class="muted">Add beliefs in the admin under About page.</p>';
} elseif ($topic === 'leaders') {
    $leaders = q('SELECT * FROM leaders ORDER BY sort_order, id');
    echo '<div class="grid three">';
    foreach ($leaders as $l) {
        echo '<article class="card">';
        echo $l['photo'] ? '<img class="avatar" src="' . e($l['photo']) . '" alt="' . e($l['name']) . '">'
            : '<div class="avatar ph" aria-hidden="true">' . e(implode('', array_map(fn($w) => mb_substr($w, 0, 1), array_slice(explode(' ', (string)$l['name']), 0, 2)))) . '</div>';
        echo '<h3>' . e($l['name']) . '</h3><p class="muted">' . e($l['position']) . '</p><p>' . e($l['bio']) . '</p>';
        echo '<ul>' . implode('', array_map(fn($r) => '<li>' . e($r) . '</li>', lines($l['responsibilities']))) . '</ul></article>';
    }
    echo '</div>';
    if (!$leaders) echo '<p class="muted">Add leaders in the admin to show them here.</p>';
}

foreach ($blocks as $b) {
    $text = (trim((string)$b['heading']) !== '' ? '<h2>' . e($b['heading']) . '</h2>' : '') . about_paragraphs($b['body']);
    $media = $b['image'] ? '<img class="abimg" src="' . e($b['image']) . '" alt="' . e($b['heading']) . '">' : '';
    echo about_block($text, $media, $i++);
}
?>
<p class="abmore-h">Explore more</p>
<p class="abmore"><?php foreach ($topics as $o) if ($o['slug'] !== $topic) echo '<a href="/about/' . e($o['slug']) . '">' . e($o['title']) . '</a>'; ?></p>
</div>
<?php foot();